# -*- coding: utf-8 -*-
"""
Created on Mon Oct 14 09:28:21 2024

@author: LF
"""
'''本程序用于计算有关干旱的统计量'''
#注意多处更换4/5/6阶段  
import os
import re
import glob 
import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%
dur_frame = pd.DataFrame(columns = ['siteid', 'dur'])
freq_frame = pd.DataFrame(columns = ['siteid', 'freq'])
inten_frame = pd.DataFrame(columns = ['siteid', 'inten'])
sev_frame = pd.DataFrame(columns = ['siteid', 'sev'])
dir_list = glob.glob(r'F:/phd1/V6/*/*/05SMDI/')
rr = 0
info_path = 'F:/phd1/V6/01allsite/02drought/SPEI_scale.xlsx'
site_frame = pd.read_excel(info_path, index_col=0, header=0)
for dd in dir_list:
    dd = dd.replace('\\', '/')
    substrings = re.split(r'/', dd)  # 按/分割
    igbp = substrings[3]
    siteid = substrings[4]
    scale = site_frame.loc[site_frame['siteid'] == siteid, 'SPEI_scale'].values[0]            
    csvpath1 = 'F:/phd1/V6/'+igbp+'/'+siteid+'/05SMDI/spei_smdi.csv'
    spei_smdi = pd.read_csv(csvpath1, index_col=0, parse_dates=True, header=0)
    csvpath2 = 'F:/phd1/V6/'+igbp+'/'+siteid+'/04SPEI/SPEI'+str(scale*30)+'.csv'
    spei_frame = pd.read_csv(csvpath2, index_col=0, parse_dates=True, header=0)
    csvpath3 = 'F:/phd1/V6/'+igbp+'/'+siteid+'/05SMDI/SMDI30.csv'
    smdi_frame = pd.read_csv(csvpath3, index_col=0, parse_dates=True, header=0)    
    di_frame = pd.DataFrame(spei_smdi["DI"])
    tot_num = int(di_frame.count())  #获取元素个数
    grouped = spei_smdi.groupby('DI') # 使用groupby函数按第一列分组  
    if 4 in grouped.groups:
        group_data = grouped.get_group(4)        
        print(siteid)          
        #求时长
        rows_group = group_data.shape[0]
        dur_frame.loc[rr,'siteid'] = siteid
        dur_frame.loc[rr,'dur'] = rows_group
        #求频率
        freq = rows_group/tot_num
        freq_frame.loc[rr,'siteid'] = siteid
        freq_frame.loc[rr,'freq'] = freq
        #求强度intensity
        spei_group = spei_frame.reindex(group_data.index)
        smdi_group = smdi_frame.reindex(group_data.index)
        intensity = np.sqrt(spei_group.values**2 + smdi_group.values**2)
        inten_frame.loc[rr,'siteid'] = siteid
        inten_frame.loc[rr,'inten'] = np.sum(intensity)
        #求严重度severity        
        sev_frame.loc[rr,'siteid'] = siteid
        sev_frame.loc[rr,'sev'] = np.sum(intensity)/rows_group
        rr+=1
    else:
        print(siteid,"没有5的数据。")
dur_frame.to_csv('F:/phd1/V6/01allsite/08RF/varix/duration_4.csv', index=True, header=True, float_format='%.4f')            
freq_frame.to_csv('F:/phd1/V6/01allsite/08RF/varix/frequency_4.csv', index=True, header=True, float_format='%.4f')
inten_frame.to_csv('F:/phd1/V6/01allsite/08RF/varix/intensity_4.csv', index=True, header=True, float_format='%.4f')
sev_frame.to_csv('F:/phd1/V6/01allsite/08RF/varix/severity_4.csv', index=True, header=True, float_format='%.4f')        

