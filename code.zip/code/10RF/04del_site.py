#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan  9 17:00:53 2025

@author: lifeng
"""
'''本程序用于删除不符合过滤条件的要素.'''
import geopandas as gpd
import pandas as pd
import numpy as np
#%%
ndvi_path = 'F:/phd1/V6/01allsite/08RF/sitefilter/ndvi_filter.xlsx'
ndvi_frame = pd.read_excel(ndvi_path, index_col=0, header=0)[['siteid','site_max']]
lulc_path = 'F:/phd1/V6/01allsite/08RF/sitefilter/lulc_filter.xlsx'
lulc_frame = pd.read_excel(lulc_path, index_col=0, header=0)[['siteid','max_bool']]
# 按site合并
df_merged = ndvi_frame.merge(lulc_frame, on='siteid')
# 逻辑与运算
df_merged['filter_bool'] = df_merged['site_max'] & df_merged['max_bool']
# 只保留site和最终的bool值
filter_df = df_merged[['siteid', 'filter_bool']]
dem_path = 'F:/phd1/V6/01allsite/01siteinfo/siteinfo_dem.csv'
dem_frame = pd.read_csv(dem_path, index_col=0, header=0)
# 获取 df_final 中 final_value 为 True 的站点名称
valid_sites = set(filter_df.loc[filter_df['filter_bool'], 'siteid'])
# 筛选 df 中 site 在 valid_sites 内的行
dem_filter = dem_frame[dem_frame['siteid'].isin(valid_sites)].reset_index(drop=True)
# 导出为 Excel
dem_filter.to_excel("F:/phd1/V6/01allsite/08RF/sitefilter/dem_filter.xlsx", index=True, header=True)

#%%
# 读取Shapefile
shp_file = 'F:/phd1/V6/01allsite/01siteinfo/siteinfo_buffer.shp'  # 请替换为你的Shapefile路径
gdf = gpd.read_file(shp_file)
print(gdf.head())  # 打印前几行数据查看结构
# 筛选 gdf 中 siteid 在 df_filtered['site'] 里的行
filtered_gdf = gdf[gdf['siteid'].isin(dem_filter['siteid'])]
# 导出修改后的Shapefile
filtered_gdf.to_file('F:/phd1/V6/01allsite/08RF/sitefilter/buffer_filter.shp')


