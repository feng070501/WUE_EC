# -*- coding: utf-8 -*-
"""
Created on Mon Oct 14 21:23:55 2024

@author: LF
"""
'''本程序用于提取有关土壤属性的统计量'''
import os
import glob
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import rioxarray as rxr
import geopandas as gpd
from rasterstats import zonal_stats
from concurrent.futures import ThreadPoolExecutor
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%提取土壤属性
def ext_soil(invari, outvari):
    shp_file = "/public/data/lifeng/phd1/rasterdata/filter_buffer.shp"
    gdf = gpd.read_file(shp_file, encoding='utf-8')
    tif_tif = rxr.open_rasterio('/public/data/lifeng/phd1/rasterdata/soil/'+invari+'.tif', nodata=-32768)
    #tif_tif = tif_tif.where(tif_tif < 0, np.nan)
    if gdf.crs != tif_tif.rio.crs:
        gdf = gdf.to_crs(tif_tif.rio.crs)
    plt.imshow(tif_tif)
    plt.show()
    # 将 DataArray 保存为临时 tif 文件
    tif_path = '/public/data/lifeng/phd1/rasterdata/temp/'+invari+'.tif'
    tif_tif.rio.to_raster(tif_path)
    tif_ext = zonal_stats(
        gdf,
        tif_path,
        stats="mean",  # 可以指定多个统计量，例如 "min", "max", "median", "mean" 等
        geojson_out=True,  # 如果需要保留与矢量面对应的信息
        multiprocessing=True,
        all_touched=True
    )
    # 从 stats 提取 siteid 和 mean 值
    feature_data = [{"siteid": feature["properties"]["siteid"], "mean_value": feature["properties"]["mean"]} for feature in tif_ext]
    # 构建 DataFrame
    tif_ext1 = pd.DataFrame(feature_data)
    tif_ext1.to_excel('/public/data/lifeng/phd1/varix/soil/'+outvari+'.xlsx', index=True, header=True, float_format='%.4f')
    return tif_ext1
data_dir = glob.glob('/public/data/lifeng/phd1/rasterdata/soil/*.tif')
# # 提取文件名（去掉扩展名）
var_list = [os.path.splitext(os.path.basename(dd))[0] for dd in data_dir]
# 并行处理
if __name__ == "__main__":
    max_workers = os.cpu_count()  # 最大使用 CPU 核心数
    with ThreadPoolExecutor(max_workers=8) as executor:
        resultslist = list(executor.map(ext_soil, var_list, var_list))

