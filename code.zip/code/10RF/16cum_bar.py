# -*- coding: utf-8 -*-
"""
Created on Mon Feb  3 10:50:01 2025

@author: LF
"""
'''本程序用于绘制SHAP的柱状图。'''
####注意更改首尾的变量名
import glob
import re
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%% 整合数据
dir_list = glob.glob(r'F:/phd1//01allsite/08RF/*/Gc_*.xlsx')
shap_df = pd.DataFrame()
for dd in dir_list:
    dd = dd.replace('\\', '/')
    substrings = re.split(r'/', dd)  # 按/分割
    methods = substrings[5]
    phase = os.path.splitext(os.path.basename(dd))[0].split('_')[-1][-1]  #获取变量               
    data = pd.read_excel(dd, index_col=False, header=0)   
    col_sr = pd.Series()
    for rr in range(8):
        col_sr.at[0] = methods
        col_sr.at[1] = data.loc[rr,'Variable'].split('_')[0]
        col_sr.at[2] = phase
        col_sr.at[3] = data.loc[rr,'Mean_SHAP_Value']
        shap_df = pd.concat([shap_df, col_sr.to_frame().T], ignore_index=True)
shap_df.columns=['methods','variable', 'phases', 'shapvalue']
method_list = list(shap_df['methods'].unique())
vari_list = list(shap_df['variable'].unique())
phase_list = list(shap_df['phases'].unique())
#%% 筛选X轴变量
# 计算每个变量出现的次数
var_counts = shap_df['variable'].value_counts()
# 提取出现次数最多的前8个变量
top8_by_count = var_counts.head(8).index.tolist()
# 对这8个变量计算 shapvalue 总和，并按总和降序排序
shap_sums = shap_df[shap_df['variable'].isin(top8_by_count)].groupby('variable')['shapvalue'].sum()
# 排序并取出变量列表（降序：从大到小）
top8_vars_sorted = shap_sums.sort_values(ascending=False).index.tolist()
# 精简 DataFrame，只保留包含这8个变量的行 ---
shap_filtered = shap_df[shap_df['variable'].isin(top8_vars_sorted)]
#%% 重分类颜色
category_map = {
    'N15': 'PFTs',
    'SL': 'PFTs',
    'pre': 'meteorology',
    'inten': 'meteorology',
    'P50': 'PFTs',
    'WVL': 'PFTs',
    'C4': 'PFTs',
    'sand': 'soil',
    'freq': 'meteorology',
    'DM': 'PFTs',
    'WD': 'PFTs',
    'silt': 'soil',
    'Tmax': 'meteorology',
    'BD': 'soil',
    'Tmean': 'meteorology',
    'SLA': 'PFTs',
    'LA': 'PFTs',
    'RD': 'PFTs',
    'soc': 'soil',
    'LDMC': 'PFTs',
    'PSR': 'PFTs',
    'Vcmax': 'PFTs',
    'Gpmax': 'PFTs',
    'LFM': 'PFTs',
    'PHR': 'PFTs',
    'smph': 'soil',
    'seve': 'meteorology',
    'Cmass': 'PFTs',
    'LPC': 'PFTs',
    'SCD': 'PFTs',
    'Rnet':'meteorology',
    'DUL': 'PFTs',
    'RN': 'hydrology',
    'WS': 'meteorology',
    'VCH': 'PFTs',
    'LNC': 'PFTs',
    'STN': 'soil',
    'cecph': 'soil',
    'AI': 'meteorology',
    'SSD':'PFTs',
    'VPD':'meteorology',
    'clay': 'soil',
    'socd': 'soil',
    'GTD': 'hydrology',
    'SN': 'PFTs',
    'socs': 'soil',
    'dur': 'meteorology',
    'N': 'PFTs'
}
# 自定义颜色映射字典
custom_palette = {
    'meteorology': '#c5272d',  
    'hydrology': '#1868b2',  
    'soil': '#f3a332',  
    'PFTs': '#018a67',
    '0': '#000000'
}
# 在df中创建新列并填入类别
shap_filtered['class'] = shap_filtered['variable'].map(category_map)
colors = {'4': '#1f77b4', '5': '#eb8928', '6': '#2ca02c'}
#%%分模型、分阶段绘制柱子
parameters = {'axes.labelsize': 40,
          'axes.titlesize': 20,
          'xtick.labelsize': 35,
          'ytick.labelsize': 35,
          'figure.dpi': 300,
          'lines.linewidth': 2,
          'font.family': 'Arial',
          'axes.titlepad': 20}
plt.rcParams.update(parameters)
# 按总 SHAP 值从低到高排序变量
sorted_vars = shap_sums.sort_values(ascending=True).index.tolist()
# 创建一个子图
fig, ax = plt.subplots(figsize=(15, 12))
# Y轴位置按照 sorted_vars 来排列
y = np.arange(len(sorted_vars))
bar_height = 0.6
# 初始化左侧位置为 0
left = np.zeros(len(sorted_vars))
# 遍历每个阶段
for t in phase_list:
    # 计算每个变量在当前阶段的 SHAP 值总和
    values = []
    method_counts = []
    for var in sorted_vars:
        temp = shap_filtered[(shap_filtered['variable'] == var) & (shap_filtered['phases'] == t)]
        value = temp['shapvalue'].sum() if not temp.empty else 0
        values.append(value)
        # 统计有值的 methods 数量
        method_count = temp['methods'].nunique() if not temp.empty else 0
        method_counts.append(method_count)
    # 绘制堆叠水平柱状图
    bars = ax.barh(y, values, height=bar_height, left=left, color=colors[t], edgecolor='black', label=t)
    # 在每个堆叠部分添加文本
    for bar, count in zip(bars, method_counts):
        if bar.get_width() > 0:  # 仅在宽度大于0时添加文本
            ax.text(bar.get_x() + bar.get_width() / 2, bar.get_y() + bar.get_height() / 2,
                    str(count), ha='center', va='center', fontsize=35, color='white')
    # 更新左侧位置
    left += values
# 添加图例
ax.legend(bbox_to_anchor=(0.9, 0.35), frameon=False, fontsize=35, bbox_transform=fig.transFigure)
# 去掉右边和上边的边框
ax.spines['right'].set_visible(False)
ax.spines['top'].set_visible(False)
# 设置所有子图共用的 X 轴刻度和标签
ax.set_yticks(y)
ax.set_yticklabels(sorted_vars)
# 设置 X 轴标签
ax.set_xlabel('SHAP Value')
plt.tight_layout()
plt.savefig('F:/phd1//01allsite/08RF/factors/Gc_factors.jpg', dpi=300)
plt.show()

#%%
