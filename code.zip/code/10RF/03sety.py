# -*- coding: utf-8 -*-
"""
Created on Fri Oct 11 16:52:03 2024

@author: LF
"""
'''本程序用于准备各站点WUE的5阶段偏移量'''
#注意更换4/5/6阶段
import os
import re
import glob 
import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%
et_y = pd.DataFrame(columns = ['siteid', 'et'])
t_y = pd.DataFrame(columns = ['siteid', 't'])
gpp_y = pd.DataFrame(columns = ['siteid', 'gpp'])
gc_y = pd.DataFrame(columns = ['siteid', 'gc'])
ewue_y = pd.DataFrame(columns = ['siteid', 'EWUE'])
twue_y = pd.DataFrame(columns = ['siteid', 'TWUE'])
iwue_y = pd.DataFrame(columns = ['siteid', 'IWUE'])
dir_list = glob.glob(r'F:/phd1//*/*/06WUE/')
rr = 0
for dd in dir_list:
    dd = dd.replace('\\', '/')
    substrings = re.split(r'/', dd)  # 按/分割
    igbp = substrings[3]
    siteid = substrings[4]        
    csvpath1 = os.path.join(dd, 'ewue_zscflt.csv')
    ewue_frame = pd.read_csv(csvpath1, index_col=0, parse_dates=True, header=0)
    csvpath2 = os.path.join(dd, 'twue_zscflt.csv')
    twue_frame = pd.read_csv(csvpath2, index_col=0, parse_dates=True, header=0)
    csvpath3 = os.path.join(dd, 'iwue_zscflt.csv')
    iwue_frame = pd.read_csv(csvpath3, index_col=0, parse_dates=True, header=0)
    csvpath4 = 'F:/phd1//'+igbp+'/'+siteid+'/03data_flt/data_zscflt.csv'
    ori_frame = pd.read_csv(csvpath4, index_col=0, parse_dates=True, header=0)
    et_frame = ori_frame['et']
    gpp_frame = ori_frame['gpp']
    t_frame = ori_frame['t']
    csvpath5 = 'F:/phd1//'+igbp+'/'+siteid+'/05SMDI/spei_smdi.csv'
    spei_smdi = pd.read_csv(csvpath5, index_col=0, parse_dates=True, header=0)
    csvpath6 = 'F:/phd1//'+igbp+'/'+siteid+'/06WUE/gc_zscflt.csv'
    gc_frame = pd.read_csv(csvpath6, index_col=0, parse_dates=True, header=0)
    di_frame = pd.DataFrame(spei_smdi["DI"])
    common_df1 = pd.merge(di_frame, et_frame, how='inner', left_index=True, right_index=True) #取交集合并各dataframe
    common_df2 = pd.merge(common_df1, t_frame, how='inner', left_index=True, right_index=True)
    common_df3 = pd.merge(common_df2, gpp_frame, how='inner', left_index=True, right_index=True)
    common_df4 = pd.merge(common_df3, gc_frame, how='inner', left_index=True, right_index=True)
    common_df5 = pd.merge(common_df4, ewue_frame, how='inner', left_index=True, right_index=True)
    common_df6 = pd.merge(common_df5, twue_frame, how='inner', left_index=True, right_index=True)
    common_df = pd.merge(common_df6, iwue_frame, how='inner', left_index=True, right_index=True)
    common_df.dropna(inplace=True) #删除nan位置所在的元素        
    # outpath = 'F:/phd1//'+igbp+'/'+siteid+'/10RF'
    # os.makedirs(outpath, exist_ok=True)  #创建文件夹
    grouped = common_df.groupby('DI') # 使用groupby函数按第一列分组    
    if 6 in grouped.groups:
        group_data = grouped.get_group(6)
        print(siteid)            
        group_data['et'].to_csv('F:/phd1//'+igbp+'/'+siteid+'/10RF/y6_ET.csv', index=True, header=True, float_format='%.4f')
        group_data['t'].to_csv('F:/phd1//'+igbp+'/'+siteid+'/10RF/y6_T.csv', index=True, header=True, float_format='%.4f')
        group_data['gpp'].to_csv('F:/phd1//'+igbp+'/'+siteid+'/10RF/y6_GPP.csv', index=True, header=True, float_format='%.4f')
        group_data['gc'].to_csv('F:/phd1//'+igbp+'/'+siteid+'/10RF/y6_gc.csv', index=True, header=True, float_format='%.4f')
        group_data['EWUE'].to_csv('F:/phd1//'+igbp+'/'+siteid+'/10RF/y6_EWUE.csv', index=True, header=True, float_format='%.4f')
        group_data['TWUE'].to_csv('F:/phd1//'+igbp+'/'+siteid+'/10RF/y6_TWUE.csv', index=True, header=True, float_format='%.4f')
        group_data['IWUE'].to_csv('F:/phd1//'+igbp+'/'+siteid+'/10RF/y6_IWUE.csv', index=True, header=True, float_format='%.4f')
        et_y.loc[rr,'siteid'] = siteid
        et_y.loc[rr,'et'] = group_data['et'].mean()
        t_y.loc[rr,'siteid'] = siteid
        t_y.loc[rr,'t'] = group_data['t'].mean()
        gpp_y.loc[rr,'siteid'] = siteid
        gpp_y.loc[rr,'gpp'] = group_data['gpp'].mean()
        gc_y.loc[rr,'siteid'] = siteid
        gc_y.loc[rr,'gc'] = group_data['gc'].mean()
        ewue_y.loc[rr,'siteid'] = siteid
        ewue_y.loc[rr,'EWUE'] = group_data['EWUE'].mean()
        twue_y.loc[rr,'siteid'] = siteid
        twue_y.loc[rr,'TWUE'] = group_data['TWUE'].mean()
        iwue_y.loc[rr,'siteid'] = siteid
        iwue_y.loc[rr,'IWUE'] = group_data['IWUE'].mean()
        rr+=1
    else:
        print(siteid,"没有6的数据。")
et_y.to_csv('F:/phd1//01allsite/08RF/variy_6/et_y6.csv', index=True, header=True, float_format='%.4f')
t_y.to_csv('F:/phd1//01allsite/08RF/variy_6/t_y6.csv', index=True, header=True, float_format='%.4f')            
gpp_y.to_csv('F:/phd1//01allsite/08RF/variy_6/gpp_y6.csv', index=True, header=True, float_format='%.4f')
gc_y.to_csv('F:/phd1//01allsite/08RF/variy_6/gc_y6.csv', index=True, header=True, float_format='%.4f')
ewue_y.to_csv('F:/phd1//01allsite/08RF/variy_6/ewue_y6.csv', index=True, header=True, float_format='%.4f')
twue_y.to_csv('F:/phd1//01allsite/08RF/variy_6/twue_y6.csv', index=True, header=True, float_format='%.4f')
iwue_y.to_csv('F:/phd1//01allsite/08RF/variy_6/iwue_y6.csv', index=True, header=True, float_format='%.4f')           
