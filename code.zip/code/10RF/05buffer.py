#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jan  5 11:53:37 2025

@author: lifeng
"""
'''本程序用于创建特定站点的buffer.'''
import pandas as pd
import geopandas as gpd
from shapely.geometry import Point
import matplotlib.pyplot as plt
#%%
# 读取CSV文件，包含站点经纬度
site_df = pd.read_excel("F:/phd1/V6/01allsite/08RF/sitefilter/dem_filter.xlsx")  # 请根据实际路径修改

# 创建一个GeoDataFrame来存储站点经纬度
geometry = [Point(lon, lat) for lon, lat in zip(site_df['lon'], site_df['lat'])]
gdf = gpd.GeoDataFrame(site_df, geometry=geometry)

# 设置坐标参考系（假设数据使用WGS84坐标系）
gdf.crs = "EPSG:4326"

# 将经纬度转为投影坐标系（UTM）
gdf = gdf.to_crs(epsg=3395)  # UTM投影（米为单位）

# 创建每个站点5公里半径的缓冲区
gdf['buffer'] = gdf.geometry.buffer(5000)  # 5000米即5公里

# 设置输出路径
output_shp = "F:/phd1/V6/01allsite/08RF/sitefilter/filter_buffer.shp"

# 保存为Shapefile文件
gdf[['siteid', 'lat', 'lon', 'buffer']].to_file(output_shp)
#%%
# 创建一个简单的matplotlib图形
fig, ax = plt.subplots(figsize=(10, 10))

# 绘制缓冲区（5公里）
gdf['buffer'].plot(ax=ax, color='blue', edgecolor='blue', alpha=1)
# 绘制站点
#gdf.plot(ax=ax, color='red', marker='o', markersize=5, label='site')
# 显示图形
plt.show()

