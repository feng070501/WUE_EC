"""Climate indices for drought monitoring"""
