# -*- coding: utf-8 -*-
"""
Created on Mon Sep 16 15:29:49 2024

@author: LF
"""
'''本程序用于根据最大相关系数、条件概率和交叉小波变换确定站点SPEI的时间尺度。'''
#注意更改IGBP
import numpy as np
import pandas as pd
import glob
import re
import os
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%
info_path = 'F:/phd1/V6/01allsite/01siteinfo/siteinfo_dem.csv'
site_frame = pd.read_csv(info_path, index_col=0, header=0)
dir_list = glob.glob(r'F:/phd1/V6/*/*/04SPEI/')
for dd in dir_list:
    dd = dd.replace('\\', '/')
    substrings = re.split(r'/', dd)  # 按/分割
    igbp = substrings[3]
    siteid = substrings[4]
    cofe_list = []
    csvpath1 = os.path.join(dd, 'max_cc.csv')
    max_cc = pd.read_csv(csvpath1, index_col=0, header=0)
    csvpath2 = os.path.join(dd, 'condi_prob.csv')
    condi_prob = pd.read_csv(csvpath2, index_col=0, header=0)
    csvpath3 = os.path.join(dd, 'xwt.xlsx')
    xwt = pd.read_excel(csvpath3, index_col=None, header=None)
    max_cc_max = max_cc.idxmax()[0]
    cofe_list.append(max_cc_max)
    condi_prob_max = condi_prob.idxmax()[0]
    cofe_list.append(condi_prob_max)    
    cofe_list.append(xwt.values[0][0])
    scale = np.nanmedian(cofe_list)
    site_frame.loc[site_frame['siteid'] == siteid, 'SPEI_scale'] = scale    
    print(siteid)
site_frame.to_excel('F:/phd1/V6/01allsite/02drought/SPEI_scale.xlsx')    
