# -*- coding: utf-8 -*-
"""
Created on Tue Apr  9 21:57:13 2024

@author: LF
"""
'''本程序用于根据SPEI和SWDI划分干旱与非干旱时段'''
#注意更改IGBP
import pandas as pd
import numpy as np
import os
import re
import glob
import matplotlib.pyplot as plt
from matplotlib.patches import ConnectionPatch
from matplotlib.ticker import MaxNLocator
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%
def reclass(df):
    arr = df.values
    col_name = df.columns
    # 定义条件和对应值
    conditions = [
        arr > 0.5,
        np.logical_and(arr <= 0.5, arr >= -0.5),
        np.logical_and(arr <= -0.5, arr >= -1.5),
        arr < -1.5
    ]
    choices = [np.nan, 1, 0, -1]
    # 应用分类规则
    arr_class = np.select(conditions, choices, default=np.nan)
    class_df = pd.DataFrame(arr_class, index = df.index, columns=col_name)
    return class_df
#检查标签是否重叠
def rotate_labels(ax):
    # 获取当前的x轴标签
    labels = ax.get_xticklabels()
    # 获取标签的位置
    positions = ax.get_xticks()   
    # 计算标签的宽度
    label_widths = [label.get_window_extent().width for label in labels]    
    # 检查标签是否重叠
    overlapping = False
    for i in range(len(labels) - 1):
        if positions[i + 1] - positions[i] < label_widths[i] + label_widths[i + 1]:
            overlapping = True
            break    
    # 如果标签重叠，则旋转标签；否则不旋转
    if overlapping:
        ax.set_xticklabels(labels, rotation=45, ha='right')
    else:
        ax.set_xticklabels(labels, rotation=0)
#%%读入数据
info_path = '/01allsite/02drought/SPEI_scale.xlsx'
site_frame = pd.read_excel(info_path, index_col=0, header=0)
dir_list = glob.glob('/ENF/*/05SMDI/SMDI30.csv')
for dd in dir_list:
    dd = dd.replace('\\', '/')
    substrings = re.split(r'/', dd)  # 按/分割
    igbp = substrings[3]
    siteid = substrings[4]
    scale = int(site_frame.loc[site_frame['siteid'] == siteid, 'SPEI_scale'].values[0])
    csvpath1 = '/'+igbp+'/'+siteid+'/04SPEI/SPEI'+str(scale*30)+'.csv'
    spei = pd.read_csv(csvpath1, index_col='TIMESTAMP', parse_dates=True, header=0)    
    smdi = pd.read_csv(dd, index_col=0, parse_dates=True, header=0)
    spei_class = reclass(spei)
    smdi_class = reclass(smdi)    
    #筛选出2个指数共同非NaN的值
    spei_smdi = pd.concat([spei_class, smdi_class], axis=1)     
            
    #给干旱事件分阶段
    spei_smdi.loc[(spei_smdi['SPEI'] == 1) & (spei_smdi['SMDI'] == 1), 'DI'] = 1
    spei_smdi.loc[(spei_smdi['SPEI'] == 0) & (spei_smdi['SMDI'] == 1), 'DI'] = 2
    spei_smdi.loc[(spei_smdi['SPEI'] == 0) & (spei_smdi['SMDI'] == 0), 'DI'] = 3
    spei_smdi.loc[(spei_smdi['SPEI'] == -1) & (spei_smdi['SMDI'] == 0), 'DI'] = 4
    spei_smdi.loc[(spei_smdi['SPEI'] == -1) & (spei_smdi['SMDI'] == -1), 'DI'] = 5
    spei_smdi.loc[(spei_smdi['SPEI'] == 0) & (spei_smdi['SMDI'] == -1), 'DI'] = 6
    spei_smdi.loc[(spei_smdi['SPEI'] == 1) & (spei_smdi['SMDI'] == 0), 'DI'] = 8
    num_rows = spei_smdi.shape[0]
    for rr in range(1, num_rows):        
        if spei_smdi.at[spei_smdi.index[rr],'DI'] == 3:
            try:
                if spei_smdi.at[spei_smdi.index[rr-1],'DI'] == 6 or spei_smdi.at[spei_smdi.index[rr+1],'DI'] == 8:
                    spei_smdi.at[spei_smdi.index[rr],'DI'] = 7
                elif spei_smdi.at[spei_smdi.index[rr-1],'DI'] == 7 or spei_smdi.at[spei_smdi.index[rr+1],'DI'] == 7:
                    spei_smdi.at[spei_smdi.index[rr],'DI'] = 7
            except IndexError:  #跳过报错  
                pass   
    spei_smdi1 = spei_smdi.copy()
    dry_index = spei_smdi1['DI']
    lengths = dry_index.groupby((dry_index != dry_index.shift()).cumsum()).transform('size') #每次连续取值的长度
    dry_index[lengths <= 3] = np.nan   #去掉连续天数小于3天的时间段
    spei_smdi1['DI'] = dry_index
    spei_smdi1.to_csv('/'+igbp+'/'+siteid+'/05SMDI/spei_smdi.csv', index=True, header=True)
        
    #绘柱状图        
    parameters = {'axes.labelsize': 30,
              'axes.titlesize': 30,
              'xtick.labelsize': 25,
              'ytick.labelsize': 25,
              'figure.dpi': 300,
              'lines.linewidth': 4,
              'font.family': 'Arial',
              'axes.titlepad': 20}
    plt.rcParams.update(parameters)
    fig, axs = plt.subplots(2, 1, figsize=(12, 10), dpi=300)
    
    cmap = plt.get_cmap('tab10')  # 使用viridis颜色映射，将颜色分成9个区间
    #干旱指数的类别与色带索引对应
    value_to_color_index = {
        1: 0,  # Set2的第3个颜色 (索引从0开始，所以2是第3个)
        2: 4,  # Set2的第7个颜色
        3: 2,  # Set2的第1个颜色
        4: 1,  # Set2的第2个颜色
        5: 3,  # Set2的第4个颜色
        6: 5,  # Set2的第5个颜色
        7: 8,  # Set2的第6个颜色
        8: 6,  # Set2的第8个颜色    
    }
    # 绘制每个柱子
    drought_class = spei_smdi1['DI']
    for i, v in enumerate(drought_class):
        color_index = value_to_color_index.get(v,0)  # 根据值选键
        axs[0].bar(spei_smdi1.index.values[i], v, color=cmap(color_index))
    
    axs[0].yaxis.set_major_locator(MaxNLocator(integer=True))  # 设置y轴刻度只显示整数
    axs[0].set_ylabel('Drought phases', labelpad=20)
    axs[0].set(title=f'Drought evolution process at {siteid}')  # 设置axes及子图标题
    rotate_labels(axs[0])
    
    #%绘制饼图
    fig.delaxes(axs[1])
    #计算唯一值的频率占比
    value_count = drought_class.value_counts(dropna=False)
    # 计算百分比占比
    percentages = (value_count / len(drought_class)) * 100
    # 仅保留 1~8 的百分比占比
    unique_values = range(1, 9)
    percentages_filtered = percentages.reindex(unique_values, fill_value=0) 
    pie_path = '/'+igbp+'/'+siteid+'/05SMDI/di_percentage.xlsx'
    percentages_filtered.to_excel(pie_path, index=True, header=True, float_format='%.2f')
    try:        
        axs1 = fig.add_axes([-0.1, -0.15, 0.8, 0.5])  #[left, bottom, width, height]
        colors = [cmap(value_to_color_index.get(value,0)) for value in percentages_filtered.index.values]
        wedges, texts, autotexts = axs1.pie(percentages_filtered, autopct='%1.1f%%', colors=colors, startangle=90)
        
        centre_circle = plt.Circle((0, 0), 0.4, fc='white')  # 添加中心的圆圈以形成环状
        fig.gca().add_artist(centre_circle)
        axs1.set_title('Proportion of drought phases', loc='right')  # 右对齐
        axs1.axis('equal')   # 保证环状饼图是圆形
        for autotext in autotexts:
            x, y = autotext.get_position()
            autotext.set_position((1.2 * x, 1.2 * y))  # 将文本位置缩放，使其位于环内
        plt.setp(autotexts, size=30)  # 设置字体大小
        for tt in range(len(autotexts)):
            ratio = float(autotexts[tt].get_text()[:-1])
            if ratio < 3:
                plt.setp(autotexts[tt], size=20)  # 设置字体大小        
                x, y = autotexts[tt].get_position()  # 获取当前文本的坐标        
                autotexts[tt].set_position((x * 1.3, y * 1.3))  # 调整坐标位置，例如：使其稍微远离中心        
                autotexts[tt].set_fontweight('bold')  # 设置字体加粗
            elif 3 <= ratio < 5:
                plt.setp(autotexts[tt], size=20)  # 设置字体大小
            elif 5 <= ratio < 10:
                plt.setp(autotexts[tt], size=25)
        labels = [r'1(SPEI$_N$-SMDI$_N$)','2(SPEI$_M$-SMDI$_N$)','3(SPEI$_M$-SMDI$_M$)','4(SPEI$_E$-SMDI$_M$)','5(SPEI$_E$-SMDI$_E$)',
                  '6(SPEI$_M$-SMDI$_E$)','7(SPEI$_M$-SMDI$_M$)','8(SPEI$_N$-SMDI$_M$)']
        
        axs1.legend(wedges, labels, bbox_to_anchor=(0.75, 1.0), frameon=False, fontsize=25, ncol=1)  # 添加图例
    except ValueError as e:
        pass        
    plt.show()  # 显示图形    
    fig.savefig('/'+igbp+'/'+siteid+'/05SMDI/spei_smdi.jpg', dpi = 300, format='jpg', bbox_inches='tight')
   
#%%

