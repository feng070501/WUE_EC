# -*- coding: utf-8 -*-
"""
Created on Wed Mar 13 15:08:33 2024

@author: LF
"""
'''本程序用于计算土壤亏缺指数SMDI。'''
#注意更改IGBP
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
import re
import glob
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%
def calcSMDI(inpath, window_size, outpath):
    """Calculate Soil Moisture Deficit Index (Narasimhan & Srinivasan, 2005)."""        
    df = pd.read_csv(inpath, index_col=0, parse_dates=True, header=0)# 读取包含土壤水分数据的 CSV 文件
    swc =df['swc_m3']
    swc_df =swc.to_frame()
    smdi = np.zeros(len(swc))# 初始化 SMDI 数组
    # 获取 timestamp 的 dayofyear 列
    swc_df['doy'] = swc_df.index.dayofyear.tolist()
    # 按 dayofyear 进行分组，并计算土壤水分的中位数、最大值和最小值
    df_doy = swc_df.groupby('doy')['swc_m3'].agg(['mean', 'max', 'min']).reset_index()
    sd_list = []        
    for i in range(0, len(smdi)):# 循环计算每个时间点的 SMDI
        SW = np.mean(swc[max(0, i - window_size + 1): i+1])# 获取窗口内的土壤水分数据
        doy_list = swc_df.iloc[max(0, i - window_size + 1): i+1, 1]# 获取窗口内的doy
        # 选择符合doy条件的行
        selected_rows = df_doy[df_doy['doy'].isin(doy_list)]    
        # 提取符合条件的行中的值，并求中位数，最大值和最小值
        MSW = selected_rows['mean'].mean()
        maxSW = selected_rows['max'].max()
        minSW = selected_rows['min'].min()    
        if SW < MSW:
            if SW == minSW:
                SD = 0
            else:
                SD = (SW - MSW) / (MSW - minSW) * 100.0
        else:
            if SW == maxSW:
                SD = 0
            else:
                SD = (SW - MSW) / (maxSW - MSW) * 100.0
        if i > window_size:
            smdi[i] = 0.5 * smdi[i] + SD / 50.0
        else:
            smdi[i] = SD / 50.0
        sd_list.append(SD)
        #print(i)    
    outSMDI=pd.DataFrame(smdi, index = swc_df.index, columns=['SMDI'])
    outSMDI.to_csv(outpath, float_format='%.4f')
    return smdi
#%%
in_list = glob.glob(r'/ENF/*/01data_dd/data_ori.csv')
for ii in in_list:
    ii = ii.replace('\\', '/')
    substrings = re.split(r'/', ii)  # 按/分割
    igbp = substrings[3]
    siteid = substrings[4]
    #os.makedirs('F:/phd1/V6/'+igbp+'/'+siteid+'/05SMDI/', exist_ok=True)
    outpath = '/'+igbp+'/'+siteid+'/05SMDI/SMDI30.csv'
    window_size = 30
    smdi = calcSMDI(ii, window_size, outpath)
    print(siteid)

