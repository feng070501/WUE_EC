# -*- coding: utf-8 -*-
"""
Created on Sun Apr 21 20:54:23 2024

@author: LF
"""
'''针对提取出的通量站点各变量数据进行清洗。'''
#注意修改IGBP
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import signal
from scipy.fftpack import fft, fftfreq
from scipy.stats import zscore
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.stattools import acf
import glob
import os
import re
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%  
def my_detrend(df):
    df1 = df.copy()
    var = df1.columns[0]
    df1.replace([np.inf, -np.inf], np.nan, inplace=True)
    df1['day_of_year'] = df1.index.day_of_year    
    nan_locs = df1[var].isna()   #找出 NaN 的位置    
    df_nonan = df1.dropna()    #去掉 NaN 值    
    # 去除 NaN 后按 day_of_year 计算均值
    mean_per_day = df_nonan.groupby('day_of_year')[var].mean()
    # 使用多项式拟合季节性周期
    degree = 5  # 选择多项式的阶数
    coeffs = np.polyfit(mean_per_day.index, mean_per_day.values, degree).flatten()  # 多项式拟合
    poly_model = np.poly1d(coeffs)
    df_nonan['seasonal_fit'] = poly_model(df_nonan['day_of_year'])
    
    detrended_values = signal.detrend(df_nonan[var]).flatten()   #去趋势   
    deseasonal_values = detrended_values - df_nonan['seasonal_fit'].values #去季节性
    df_dets = pd.DataFrame(deseasonal_values, index=df_nonan.index, columns=[var])    #创建去趋势季节后的 DataFrame   
    df_final = df1[var].to_frame().copy()
    df_final.loc[~nan_locs, var] = df_dets[var]  #将去趋势季节后的数据插入回原来的 DataFrame 中，同时保留 NaN 值
    return df_final
def rain_filter(pre):  #去除雨天
    mask = pre.values <= 0.1
    # 遍历布尔索引，并将满足条件的元素之后的两个元素赋值为 NaN
    for i in range(len(mask)):
        if pre.values[i] >= 0.1:  # 如果当前元素大于0.1
            # 将当前元素及之后的两个元素赋值为 NaN
            mask[i:i + 2] = False
    return mask
#%%
oriname_list = ['gc_ori.csv', 'ewue_ori.csv', 'twue_ori.csv', 'iwue_ori.csv']
zscname_list = ['gc_zscflt.csv', 'ewue_zscflt.csv', 'twue_zscflt.csv', 'iwue_zscflt.csv']
dir_list = glob.glob(r'F:/phd1//*/*/01data_dd/data_ori.csv')
for dd in dir_list:
    dd = dd.replace('\\', '/')
    substrings = re.split(r'/', dd)  # 按/分割
    igbp = substrings[3]
    siteid = substrings[4]
    #os.makedirs('F:/FLUX/V5/'+igbp+'/'+siteid+'/03data_flt', exist_ok=True)  #创建数据文件夹
    ori = pd.read_csv(dd, index_col=0, parse_dates=True, header=0)
    #掩膜数组
    gpp = ori.gpp
    gpp_95 = np.nanpercentile(gpp.values, 95)       #95%分位数
    gpp_mask = gpp.values > (0.1*gpp_95)
    sun_mask = (ori['rnet'].values > 0) & (ori['vpd'].values > 1)
    rain_mask = rain_filter(ori['pre'])
    close_mask = np.ones(ori.shape[0]).astype(bool)
    rnet = ori.rnet
    le = ori['le']
    he = ori['he']
    try:  #Chinaflux没有土壤热通量
        gf = ori['gf']
        delta = np.abs(rnet.values - gf.values- le.values - he.values)
        if np.isnan(delta).all():
            close_mask = np.ones_like(close_mask, dtype=bool)        
        else:
            for rr in range(rnet.shape[0]):
                if np.abs(delta[rr]) > 0.5 * np.abs(rnet.values[rr] - gf.values[rr]):
                    close_mask[rr] = False                              
    except:       
        close_mask = np.ones_like(close_mask, dtype=bool)
    all_mask = gpp_mask & sun_mask & rain_mask & close_mask
    for vv in range(len(oriname_list)):                    
        csvpath1 = 'F:/phd1//'+igbp+'/'+siteid+'/06WUE/'+oriname_list[vv]
        ori_col = pd.read_csv(csvpath1, index_col=0, parse_dates=True, header=0)
        ori_mask = ori_col.where(all_mask.reshape(-1, 1), np.nan)  # 掩膜为False的地方设为NaN                   
        try:
            dtr = my_detrend(ori_mask)  # 去趋势
            zsc_col = zscore(dtr, nan_policy='omit')
            zsc_col[zsc_col > 5] = np.nan
            zsc = pd.DataFrame(zsc_col, index = ori_col.index, columns = ori_col.columns)            
            zsc.to_csv('F:/phd1//'+igbp+'/'+siteid+'/06WUE/'+zscname_list[vv], float_format='%.4f')
        except TypeError as e:
            pass       
    #绘制散点图
    try:
        csvpath2 = 'F:/phd1//'+igbp+'/'+siteid+'/06WUE/ewue_zscflt.csv'
        ewue = pd.read_csv(csvpath2, index_col=0, parse_dates=True, header=0)
        csvpath3 = 'F:/phd1//'+igbp+'/'+siteid+'/06WUE/twue_zscflt.csv'
        twue = pd.read_csv(csvpath3, index_col=0, parse_dates=True, header=0)
        csvpath4 = 'F:/phd1//'+igbp+'/'+siteid+'/06WUE/iwue_zscflt.csv'
        iwue = pd.read_csv(csvpath4, index_col=0, parse_dates=True, header=0)
        parameters = {'axes.labelsize': 30,
                  'axes.titlesize': 30,
                  'xtick.labelsize': 30,
                  'ytick.labelsize': 30,
                  'figure.dpi': 300,
                  'lines.linewidth': 4,
                  'font.family': 'Arial'}
        plt.rcParams.update(parameters)
        sup_map = str.maketrans('23456789', '²³⁴⁵⁶⁷⁸⁹')#设置上标
        fig, axs = plt.subplots(3, 1, figsize=(22, 12), dpi=300)
        index1 = ori.index
        axs[0].scatter(index1, ewue, color='#82b4d1')
        axs[0].set_title(f'(a) {siteid} EWUE')
        axs[0].set_ylabel('mm d-1', fontsize=30,y=0.8)  # 设置y轴刻度标签
        axs[1].scatter(index1, twue, color='#e0b7b7')
        axs[1].set_title(f'(b) {siteid} TWUE')
        axs[1].set_ylabel('mm d-1'.translate(sup_map), fontsize=30, y=0.8)  # 设置y轴刻度标签
        axs[2].scatter(index1, iwue, color='#e0b7b7')
        axs[2].set_title(f'(c) {siteid} IWUE')
        axs[2].set_ylabel('gC m-2 d-1'.translate(sup_map), fontsize=30, y=0.8)  # 设置y轴刻度标签
        for i in range(3):
            axs[i].spines['top'].set_linewidth(2)  # 设置顶部边框粗细为2
            axs[i].spines['bottom'].set_linewidth(2)  # 设置底部边框粗细为2
            axs[i].spines["right"].set_color(None)# 去掉右边框
            axs[i].spines["top"].set_color(None)# 去掉上边框
            axs[i].grid(True,axis='y',c='lightgray',ls='--') #设置网格线
        # 调整子图之间的间距
        plt.tight_layout()
        plt.show()
    except:
        pass
    print(siteid)
#%%

