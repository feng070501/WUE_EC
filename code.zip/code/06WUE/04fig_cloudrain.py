# -*- coding: utf-8 -*-
"""
Created on Sun Sep 22 20:58:20 2024

@author: LF
"""
'''本程序用于绘制各植被类型的云雨图。'''
#需手动切换多处IGBP
import pandas as pd
import matplotlib.pyplot as plt
#import seaborn as sns
import os
import re
import ptitprince as pt
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%
dfs = []
for ii in range(1,9):  # 遍历每个CSV文件并绘制云雨图
    # 读取CSV文件
    csvpath = 'F:/phd1//SHR/01multisite/02group/group'+str(ii)+'.csv'
    group = pd.read_csv(csvpath, index_col=0, header=0)
    dfs.append(group)
datas = pd.concat(dfs, axis=0)   # 使用pd.concat函数进行上下合并
# csvpath = csvpath.replace('\\', '/')
# igbp = re.split(r'/', csvpath)[3]
#绘云雨图
parameters = {'axes.labelsize': 30,
          'axes.titlesize': 30,
          'xtick.labelsize': 30,
          'ytick.labelsize': 30,
          'figure.dpi': 300,    
          'font.family': 'Arial',
          'axes.titlepad': 20}
plt.rcParams.update(parameters)
tab10_colors = plt.get_cmap('tab10')
#干旱指数的类别与色带索引对应
value_to_color_index = {
    1: 0,  # tab10的第0个颜色 (索引从0开始，所以2是第3个)
    2: 4,  # tab10的第4个颜色
    3: 2,  # tab10的第2个颜色
    4: 1,  # tab10的第1个颜色
    5: 3,  # tab10的第3个颜色
    6: 5,  # tab10的第5个颜色
    7: 8,  # tab10的第8个颜色
    8: 6,  # tab10的第6个颜色    
}
dylist = ['et', 't', 'gpp', 'gc', 'EWUE', 'TWUE', 'IWUE']
for yy in dylist:
    fig, ax = plt.subplots(figsize=(12, 16))   # 创建子图
    unique_dis = datas['DI'].unique()
    di_colors = [tab10_colors(value_to_color_index[di]) for di in unique_dis] #从 tab10_colors 获取颜色       
    color_mapping = {di: di_colors[i] for i, di in enumerate(unique_dis)}  # 创建字典，将组名称映射到颜色 
    dx="DI"
    ax=pt.RainCloud(x=dx, y=yy, data=datas, palette=color_mapping, bw=0.1, width_viol=0.7, ax=ax, orient='h',alpha=0.8, pointplot=True)
    for line in ax.lines:  # 获取连接线条元素
        line.set_linewidth(4)  # 设置线条宽度为3
    ax.axvline(x=0, color='black', lw=3, linestyle='--')  # x=0的垂线
    ax.set_yticklabels(['Phase 1', 'Phase 2', 'Phase 3', 'Phase 4', 'Phase 5', 'Phase 6', 'Phase 7', 'Phase 8'])
    # 手动设置标题、坐标标签以及刻度参数    
    ax.set_xlabel(yy+' z-score', fontsize=50, fontfamily='Arial', labelpad=10)
    ax.set_ylabel('Drought Phases',fontsize=50, fontfamily='Arial', labelpad=20)    
    # 手动设置刻度标签字体
    for xlabel in ax.get_xticklabels():
        xlabel.set_fontfamily('Arial')
        xlabel.set_fontsize(40)

    for ylabel in ax.get_yticklabels():
        ylabel.set_fontfamily('Arial')
        ylabel.set_fontsize(40)
    plt.tight_layout()
    plt.show()
    fig.savefig('F:/phd1//SHR/01multisite/02group/'+yy+'_group.jpg',dpi=300, format='jpg', bbox_inches='tight')
