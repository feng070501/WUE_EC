# -*- coding: utf-8 -*-
"""
Created on Fri Sep 27 14:49:52 2024

@author: LF
"""
'''本程序用于绘制各站点转变点的箱线图。'''
#注意更改多处IGBP
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import re
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%
csvpath1 = 'F:/phd1//SHR/01multisite/04amc/GPP_tpoint.csv'
gpp_tpoint = pd.read_csv(csvpath1, index_col=0, parse_dates=True, header=0)
substrings = re.split(r'/', csvpath1)  # 按/分割
igbp = substrings[3]
csvpath2 = 'F:/phd1//SHR/01multisite/04amc/ET_tpoint.csv'
et_tpoint = pd.read_csv(csvpath2, index_col=0, parse_dates=True, header=0)
csvpath3 = 'F:/phd1//SHR/01multisite/04amc/T_tpoint.csv'
t_tpoint = pd.read_csv(csvpath3, index_col=0, parse_dates=True, header=0)
csvpath4 = 'F:/phd1//SHR/01multisite/04amc/gc_tpoint.csv'
gc_tpoint = pd.read_csv(csvpath4, index_col=0, parse_dates=True, header=0)
gc_tpoint.index = gpp_tpoint.index = t_tpoint.index = et_tpoint.index = list(range(len(gpp_tpoint)))
df = pd.concat([gc_tpoint, et_tpoint, gpp_tpoint, t_tpoint], axis=1)  # 合并这三个DataFrame
df = df.drop(columns='siteid')
#%%
parameters = {'axes.labelsize': 25,
          'axes.titlesize': 25,
          'xtick.labelsize': 20,
          'ytick.labelsize': 20,
          'figure.dpi': 300,
          'lines.linewidth': 3,
          'font.family': 'Arial'}
plt.rcParams.update(parameters)
fig, ax = plt.subplots(figsize=(12, 6))
# 计算每组的列的位置并设置背景
colors = ['#FADADD', '#B5EAD7', '#FFFACD', '#9ACDDB']  # 设置每组列的背景颜色
num_cols_per_group = 2
for i, color in enumerate(colors):
    start = i * num_cols_per_group
    end = (i + 1) * num_cols_per_group
    ax.axvspan(start + 0.5, end + 0.5, facecolor=color, alpha=0.5)
# 设置均值点的样式：marker='o' 是圆形，fillstyle='none' 表示空心
mean_props = dict(marker='o', markerfacecolor='white', markeredgecolor='black', markersize=6)
box = ax.boxplot(df.values,showmeans=True, meanprops=mean_props, patch_artist=True)  #绘制箱线图
# 自定义填充颜色和边框颜色
colors = ['#3a88c8', '#a22e45', '#3a88c8', '#a22e45', '#3a88c8', '#a22e45', '#3a88c8', '#a22e45']
# 为每个箱子设置填充色和边框颜色
for patch, color in zip(box['boxes'], colors):
    patch.set_facecolor(color)  # 设置填充颜色
    patch.set_edgecolor('black')  # 设置边框颜色
    patch.set_linewidth(1.5)      # 设置边框线的宽度
new_labels = ['SPEI', 'SMDI', 'SPEI', 'SMDI', 'SPEI', 'SMDI', 'SPEI', 'SMDI']  # 自定义刻度标签
ax.set_xticklabels(new_labels)# 设置新的刻度标签
ax.set_ylabel('Drought Thresholds', fontsize=25)
ax.text(0.14, 0.95, 'Gc', ha='center', va='center', fontsize=25, transform=ax.transAxes)  #添加文本
ax.text(0.38, 0.95, 'ET', ha='center', va='center', fontsize=25, transform=ax.transAxes)
ax.text(0.64, 0.95, 'GPP', ha='center', va='center', fontsize=25, transform=ax.transAxes)
ax.text(0.87, 0.95, 'T', ha='center', va='center', fontsize=25, transform=ax.transAxes)
plt.tight_layout()
plt.show()
fig.savefig('F:/phd1//SHR/01multisite/04amc/tp_box.jpg',dpi=300, format='jpg', bbox_inches='tight')
