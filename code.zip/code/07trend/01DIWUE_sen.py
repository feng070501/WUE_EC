# -*- coding: utf-8 -*-
"""
Created on Wed Apr 24 10:23:49 2024

@author: LF
"""
'''本程序用于对干旱指数和WUE进行趋势分析。'''
#无需更换IGBP
import pandas as pd
import numpy as np
import pymannkendall as mk
import matplotlib.pyplot as plt
import glob
import re
import os
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%时间序列的趋势分析
sen_frame = pd.DataFrame(columns= ['siteid', 'SPEI', 'SPEI_p', 'SMDI', 'SMDI_p', 'EWUE', 'EWUE_p', 'TWUE', 'TWUE_p', 'IWUE', 'IWUE_p'])#所有站点的sen
info_path = 'F:/phd1//01allsite/02drought/SPEI_scale.xlsx'
site_frame = pd.read_excel(info_path, index_col=0, header=0)
dir_list = glob.glob(r'F:/phd1//*/*/05SMDI/SMDI30.csv')
zz = 0
for dd in dir_list:
    dd = dd.replace('\\', '/')
    substrings = re.split(r'/', dd)  # 按/分割
    igbp = substrings[3]
    siteid = substrings[4]
    #os.makedirs('F:/phd1//'+igbp+'/'+siteid+'/07trend', exist_ok=True)  #创建文件夹
    ##############干旱指数
    di_sen = pd.DataFrame(index = ['trend', 'slope','Pvalue'], columns = ['SPEI', 'SMDI'])
    scale = int(site_frame.loc[site_frame['siteid'] == siteid, 'SPEI_scale'].values[0])
    csvpath1 = 'F:/phd1//'+igbp+'/'+siteid+'/04SPEI/SPEI'+str(scale*30)+'.csv'
    spei_dd = pd.read_csv(csvpath1, index_col=0, parse_dates=True, header=0)   
    smdi_dd = pd.read_csv(dd, index_col=0, parse_dates=True, header=0)
    spei_mm = spei_dd.dropna().resample('MS').mean()
    smdi_mm = smdi_dd.dropna().resample('MS').mean()    
    spei_mk = mk.seasonal_test(spei_mm['SPEI'], period = 12) # Mann-Kendall 检验和 Sen's Slope
    di_sen.loc['trend', 'SPEI'] = spei_mk.trend
    di_sen.loc['slope', 'SPEI'] = spei_mk.slope
    di_sen.loc['Pvalue', 'SPEI'] = spei_mk.p
    sen_frame.loc[zz,'siteid'] = siteid
    sen_frame.loc[zz,'SPEI'] = spei_mk.slope
    sen_frame.loc[zz,'SPEI_p'] = spei_mk.p        
    smdi_mk = mk.seasonal_test(smdi_mm['SMDI'], period = 12)
    di_sen.loc['trend', 'SMDI'] = smdi_mk.trend
    di_sen.loc['slope', 'SMDI'] = smdi_mk.slope
    di_sen.loc['Pvalue', 'SMDI'] = smdi_mk.p
    sen_frame.loc[zz,'SMDI'] = smdi_mk.slope
    sen_frame.loc[zz,'SMDI_p'] = smdi_mk.p
    di_sen.to_excel('F:/phd1//'+igbp+'/'+siteid+'/07trend/di_sen.xlsx', index=True, header=True, float_format='%.4f')
    
    ##############WUE
    wue_sen = pd.DataFrame(index = ['trend', 'slope','Pvalue'], columns = ['EWUE', 'TWUE', 'IWUE'])    
    csvpath2 = 'F:/phd1//'+igbp+'/'+siteid+'/06WUE/ewue_ori.csv'
    ewue_dd = pd.read_csv(csvpath2, index_col=0, parse_dates=True, header=0)
    csvpath3 = 'F:/phd1//'+igbp+'/'+siteid+'/06WUE/twue_ori.csv'
    twue_dd = pd.read_csv(csvpath3, index_col=0, parse_dates=True, header=0)
    csvpath4 = 'F:/phd1//'+igbp+'/'+siteid+'/06WUE/iwue_ori.csv'
    iwue_dd = pd.read_csv(csvpath4, index_col=0, parse_dates=True, header=0)
    ewue_mm = ewue_dd.dropna().resample('MS').mean()
    twue_mm = twue_dd.dropna().resample('MS').mean()
    iwue_mm = iwue_dd.dropna().resample('MS').mean()    
    ewue_mk = mk.seasonal_test(ewue_mm['EWUE'], period = 12) # Mann-Kendall 检验和 Sen's Slope
    wue_sen.loc['trend', 'EWUE'] = ewue_mk.trend
    wue_sen.loc['slope', 'EWUE'] = ewue_mk.slope
    wue_sen.loc['Pvalue', 'EWUE'] = ewue_mk.p
    sen_frame.loc[zz,'EWUE'] = ewue_mk.slope
    sen_frame.loc[zz,'EWUE_p'] = ewue_mk.p
    twue_mk = mk.seasonal_test(twue_mm['TWUE'], period = 12) # Mann-Kendall 检验和 Sen's Slope
    wue_sen.loc['trend', 'TWUE'] = twue_mk.trend
    wue_sen.loc['slope', 'TWUE'] = twue_mk.slope
    wue_sen.loc['Pvalue', 'TWUE'] = twue_mk.p
    sen_frame.loc[zz,'TWUE'] = twue_mk.slope
    sen_frame.loc[zz,'TWUE_p'] = twue_mk.p
    iwue_mk = mk.seasonal_test(iwue_mm['IWUE'], period = 12)
    wue_sen.loc['trend', 'IWUE'] = iwue_mk.trend
    wue_sen.loc['slope', 'IWUE'] = iwue_mk.slope
    wue_sen.loc['Pvalue', 'IWUE'] = iwue_mk.p
    sen_frame.loc[zz,'IWUE'] = iwue_mk.slope
    sen_frame.loc[zz,'IWUE_p'] = iwue_mk.p
    zz+=1
    wue_sen.to_excel('F:/phd1//'+igbp+'/'+siteid+'/07trend/wue_sen.xlsx', index=True, header=True, float_format='%.4f')
    print(siteid)
sen_frame.to_excel('F:/phd1//01allsite/03trend/sen.xlsx', index=True, header=True, float_format='%.4f')    
    
